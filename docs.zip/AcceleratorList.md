---
title: AcceleratorList
---
## AcceleratorList

## Properties

|Name | Type | Description | Notes|
|------------ | ------------- | ------------- | -------------|
| **entities** | [**list[AcceleratorMetadata]**](AcceleratorMetadata.html) |  | [optional] |
| **page_size** | **int** |  | [optional] |
| **page_number** | **int** |  | [optional] |
| **total** | **int** |  | [optional] |
| **previous_uri** | **str** |  | [optional] |
| **last_uri** | **str** |  | [optional] |
| **first_uri** | **str** |  | [optional] |
| **self_uri** | **str** |  | [optional] |
| **next_uri** | **str** |  | [optional] |
| **page_count** | **int** |  | [optional] |
{: class="table table-striped"}


